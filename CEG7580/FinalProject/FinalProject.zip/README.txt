~~~~~~~~~~~~~~~~~~~~~~~~~~~~ README ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Run Instructions:
	- Make sure you have the Image Processing, Signal 
	  Processing and Communications System Toolboxes
	- This code has been run and tested with MatLab R2021b
	  and R2020b

	1) Open main.m
	2) Click Run

~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Image Note ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
The images include in this project are all default images that are 
included with MatLab. If images do not open as defined, all of the
selected image have been used in lectures and come with the course
textbook and are available.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~